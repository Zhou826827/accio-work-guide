# 中胜卫浴：全球大客户识别、跟进与转化 SOP (最高版本)

## 1. 核心目标
将中胜卫浴 (Zhongsheng Sanitary Ware) 从“基础五金加工”定位转型为“高端卫浴空间解决方案商”，实现 20% 的品牌溢价，锁定非洲、中东及全球大 B 工程客户。

---

## 2. 第一阶段：金牌过滤器 (Big Client Identification)
**核心逻辑：数字指纹分析，排除零售噪音，聚焦工程大单。**

### A. 询盘语义分析
- **高净值信号**：
  - 询问具体的 **CUPC / CE / SASO 认证**。
  - 提及 **Project Budget** 或 **Tender Requirements**。
  - 对 **PVD 颜色一致性 (Color Consistency)** 有明确技术要求。
- **低价值信号**：
  - "How much for 1 set to my home?"
  - 纠结空运费用大于产品价值。

### B. 客户背调流程 (LinkedIn + Google Map)
1. **身份核实**：通过 LinkedIn 确认联系人是否为 "Project Manager" 或 "Purchase Director"。
2. **实力验证**：Google Map 搜索其实际办公地址，判断其是否有线下展厅或大型仓储。

---

## 3. 第二阶段：毅冰鱼骨图订单跟进流程 (Order SOP)
**核心逻辑：书面确认文化，消除随性沟通带来的风险。**

### 节点 1：样品批准 (PP Sample Approval)
- **动作**：拒绝 WhatsApp 语音确认，必须邮件回签。
- **关键话术**： "Please confirm the PVD Brushed Gold finish via email. Written approval is the prerequisite for production."

### 节点 2：原料入库汇报 (Material Milestone)
- **动作**：发送 304 不锈钢光谱分析仪检测短视频。
- **目的**：建立信任，打击竞争对手的 201 低端产品。

### 节点 3：装箱优化 (Nest-Packing Optimization)
- **动作**：主动提供水槽套叠包装图纸，告知节省的体积 (CBM)。
- **话术**： "We optimized the packing structure to save 20% ocean freight for your Africa project."

---

## 4. 第三阶段：针对性区域转化技巧 (Regional Strategy)

### 🌍 非洲市场：顾问式销售 (Consultant Approach)
- **痛点**：资金筹备慢、追求耐用。
- **策略**：
  - 提供 **100% Sample Refund** 政策。
  - 强调 **"Anti-Corrosion for Coastline Areas"** (针对非洲沿海城市)。
  - 给予“Warm Reminder”式跟进，保持人情互动。

### 🐫 中东市场：美学与信赖 (Aesthetic & Trust)
- **痛点**：砍价成瘾、追求视觉奢华。
- **策略**：
  - **报价预留 15% 砍价空间**。
  - 锁定 **Morandi PVD 颜色** 作为核心卖点。
  - 在 WhatsApp 建立项目群，实时推送生产进度视频。

---

## 5. 视觉赋能：3D 立体拆解图 (Explosion Diagram)
**要求**：所有工程大单回复必须附带以下视觉元素：
1. **304 不锈钢层级透视图**。
2. **PVD 真空电镀工艺层说明**。
3. **加厚消音层与防凝涂层示意图**。

---

## 6. 结语
中胜卫浴的专业性不应仅体现在产品上，更应体现在“让买家不敢犯错”的流程控制中。

**制定人**：国际站深度诊断智囊团 (TL)
**日期**：2026年5月11日
