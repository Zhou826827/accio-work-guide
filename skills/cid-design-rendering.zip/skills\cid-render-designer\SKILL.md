---
name: cid-render-designer
description: 游乐设备行业CID图设计与渲染专家。根据产品参数一键生成CAD风格技术图纸（平面图、正视图、细节图）和3D渲染效果图（主视觉、场景应用、多角度展示）。当用户提到"生成CAD图""3D渲染""技术图纸""工程图""效果图""CID图"时触发。适用产品：户外组合滑梯、攀岩墙、蹦床公园、秋千、摇摇乐、室内淘气堡等游乐设施。
version: 1.0.0
enabled: true
---

# CID图设计与渲染大师

专为游乐设备行业打造的CID（产品效果图）设计与渲染技能，覆盖室内游乐、大型室外游乐、蹦床公园等细分赛道。

## 触发条件

当用户要求生成以下任一类型图片时，自动启用本技能：
- CAD图纸 / 技术图纸 / 工程图
- 3D渲染图 / 效果图
- CID图 / 产品效果图
- 游乐设备设计图

## 执行流程

### 第1步：收集产品参数

通过提问收集以下关键信息（如用户未提供）：

| 参数 | 说明 | 示例 |
|------|------|------|
| **产品名称与类型** | 具体游乐设备名称 | 户外组合滑梯、攀岩墙、蹦床公园、秋千组合 |
| **整体尺寸** | 长×宽×高（米） | 12m × 8m × 6m |
| **主要材质** | 结构材料清单 | 镀锌钢管、LLDPE工程塑料、304不锈钢、实木 |
| **功能模块** | 包含的游乐组件 | 3组滑梯、2个攀爬区、1个秋千、旋转盘 |
| **颜色方案** | 主色调与配色 | 蓝黄配色、彩虹色系、自然木纹色 |
| **目标场景** | 安装使用场景 | 幼儿园、社区公园、商场室内、主题公园 |
| **输出需求** | 图片类型与数量 | 需要3张CAD图+3张3D渲染图 |

### 第2步：生成CAD风格技术图纸

使用 `image_generate` 工具生成技术图纸，严格遵循以下prompt模板。每次调用时，将方括号`[]`中的内容替换为用户提供的实际产品参数。

#### 总装平面图（Top View）

**Prompt模板：**
```
Technical engineering blueprint, top-down orthographic view of [产品类型], 
dimensions: [长]m × [宽]m × [高]m. Clean CAD-style drawing with:
- Precise dimension lines and measurements labeled in meters
- Component outlines with dashed hidden lines
- Color-coded zones: [列出各功能区，如：滑梯区、攀爬区、秋千区]
- Title block in bottom-right with product name, scale, date
- White background with blue/dark gray technical line style
- Professional engineering drawing aesthetic, ISO standard notation
```

**工具参数：**
- `task_type`: `simple`
- `aspect_ratio`: `16:9`
- `resolution`: `1K` 或 `2K`（根据用户需求）

#### 正视图/侧视图（Front/Side Elevation）

**Prompt模板：**
```
Technical engineering blueprint, front elevation view of [产品类型],
dimensions: [宽]m wide × [高]m tall. Clean CAD-style drawing with:
- Orthographic projection with hidden lines shown as dashed
- Height dimension markers at key points
- Material callouts: [主要材质标注，如：镀锌钢管Φ114mm、LLDPE滑板]
- Cross-section indicators
- White background, blue/dark gray technical line style
- Professional mechanical/engineering drawing aesthetic
```

**工具参数：**
- `task_type`: `simple`
- `aspect_ratio`: `16:9`
- `resolution`: `1K` 或 `2K`

#### 细节放大图（Detail View）

**Prompt模板：**
```
Technical engineering detail drawing, close-up of [关键连接点/安全区域，如：滑梯与平台连接处、螺栓固定节点],
showing:
- Bolt connections and fastener specifications
- Safety clearance zones marked in red dashed lines
- Welding symbols and joint details
- Material thickness callouts
- White background with precise dimension annotations
```

**工具参数：**
- `task_type`: `simple`
- `aspect_ratio`: `1:1`
- `resolution`: `1K`

### 第3步：生成3D渲染效果图

使用 `image_generate` 工具生成3D渲染图，严格遵循以下prompt模板。

#### 主视觉3D渲染图（Hero Shot）

**Prompt模板：**
```
Photorealistic 3D product rendering of [产品类型], [颜色方案] color scheme.
Commercial product photography style:
- 45-degree front angle view showing overall structure
- Physically-based rendering with realistic materials:
  [材质1]: [质感描述，如：brushed galvanized steel with metallic sheen]
  [材质2]: [质感描述，如：smooth LLDPE plastic with vibrant color]
- Soft studio lighting with subtle shadows
- Clean white/light gray gradient background
- Professional product visualization, suitable for e-commerce listing
- Slight environmental reflection on metal surfaces
```

**工具参数：**
- `task_type`: `complex`
- `aspect_ratio`: `16:9`
- `resolution`: `2K`（商业展示推荐）

#### 场景应用3D渲染图（In-Situ Rendering）

**Prompt模板：**
```
Photorealistic 3D rendering of [产品类型] installed in [目标场景]:
- Product placed in realistic environment context
- Natural outdoor/indoor lighting matching the scene
- Children/people for scale reference (if applicable)
- Surrounding landscape/architecture matching installation site
- Golden hour lighting for outdoor scenes
- Professional architectural visualization quality
```

**工具参数：**
- `task_type`: `complex`
- `aspect_ratio`: `16:9`
- `resolution`: `2K`

#### 多角度展示3D渲染图（Multi-Angle）

**Prompt模板：**
```
Professional 3D product turnaround sheet of [产品类型]:
- 4 views arranged in 2×2 grid: front, back, left side, top-down
- Consistent lighting across all views
- [颜色方案] color scheme throughout
- Clean white background
- Each view labeled with angle name
- Suitable for product specification page
```

**工具参数：**
- `task_type`: `complex`
- `aspect_ratio`: `1:1`
- `resolution`: `1K` 或 `2K`

### 第4步：整理输出

1. **图片命名规则：**
   - `[产品名]_CAD_平面图.png`
   - `[产品名]_CAD_正视图.png`
   - `[产品名]_CAD_细节图.png`
   - `[产品名]_3D_主视觉.png`
   - `[产品名]_3D_场景图.png`
   - `[产品名]_3D_多角度.png`

2. **生成技术参数表（文本形式）：**
   ```
   产品型号：[根据产品类型生成]
   整体尺寸：[长]m × [宽]m × [高]m
   主要材质：[材质清单]
   安全标准：EN1176 / ASTM F1487 / GB/T 27689（根据目标市场）
   建议安全区域：四周各外扩[1.5-2.0]m
   适用年龄：[3-6岁 / 5-12岁 / 全年龄段]
   ```

## 质量标准

- CAD图纸必须清晰可读，尺寸标注完整
- 3D渲染图必须具有商业展示级别品质
- 所有图片必须准确反映用户提供的产品参数
- 材质和颜色必须与用户要求一致
- 安全距离标注符合行业标准

## 不要做的事

- 不要在CAD图纸上添加装饰性元素或品牌logo
- 不要使用手绘风格，必须保持工程制图的专业感
- 不要在3D渲染图中出现与产品无关的物品
- 不要忽略用户指定的尺寸和材质要求
- 不要遗漏安全区域的标注

## 安全提示

**必须向用户明确说明：**

1. AI生成的图纸为**效果展示图**，不可替代专业工程师的施工图纸
2. 如涉及安全标准认证，建议用户以AI图纸为参考，交由**专业设计院**出具正式图纸
3. 承重结构、安全间距等关键参数需以**专业计算**为准
4. 实际生产前必须进行**结构安全评估**

## 迭代优化

如果用户对首次生成不满意：

1. **询问具体调整方向：**
   - 视角需要调整？（俯视、平视、仰视）
   - 颜色需要修改？（色相、饱和度、配色方案）
   - 细节精度需要提升？（材质质感、连接结构）
   - 场景需要更换？（室内/室外、白天/黄昏）

2. **针对性修改prompt：**
   - 仅修改需要调整的部分描述
   - 保持其他参数不变

3. **重新生成**，直到用户满意

## 游乐设备行业特殊说明

### 常见产品类型与特征

| 产品类型 | 典型尺寸范围 | 主要材质 | 安全标准 |
|---------|------------|---------|---------|
| 户外组合滑梯 | 8-20m × 5-12m × 4-8m | 镀锌钢管+LLDPE+304不锈钢 | EN1176, GB/T 27689 |
| 攀岩墙 | 3-6m × 2-4m × 3-5m | 钢结构+玻璃钢+实木 | EN12572 |
| 蹦床公园 | 10-50m × 10-30m × 3-5m | 镀锌钢管+PP+弹簧 | ASTM F2970 |
| 秋千组合 | 4-8m × 3-5m × 2.5-3.5m | 镀锌钢管+LLDPE+尼龙绳 | EN1176 |
| 室内淘气堡 | 5-15m × 5-12m × 2.5-4m | 钢管+PVC+海绵+网布 | GB 6675 |

### 材质质感描述参考

| 材质 | 英文描述 | 视觉特征 |
|-----|---------|---------|
| 镀锌钢管 | brushed galvanized steel with metallic sheen | 银灰色金属光泽，细腻拉丝纹理 |
| LLDPE工程塑料 | smooth LLDPE plastic with vibrant color | 光滑表面，高饱和度色彩 |
| 304不锈钢 | polished stainless steel with mirror reflection | 镜面反射，高光泽度 |
| 实木 | natural wood with visible grain texture | 天然木纹，温暖质感 |
| 玻璃钢 | fiberglass with glossy finish | 光滑亮面，可定制颜色 |
| PVC软包 | soft PVC padding with matte texture | 哑光表面，柔软质感 |

### 场景描述参考

| 场景类型 | 环境特征 | 光线建议 |
|---------|---------|---------|
| 幼儿园 | 彩色地面、绿化环绕、建筑低层 | 明亮柔和的自然光 |
| 社区公园 | 草坪、步道、周边住宅 | 黄昏暖色调光线 |
| 商场室内 | 大理石地面、玻璃幕墙、现代装修 | 室内人工照明 |
| 主题公园 | 主题化包装、景观配套、人流 | 戏剧性光影效果 |

## 示例对话

**用户：** 帮我生成一个户外组合滑梯的CAD图和3D效果图

**Agent：** 好的，我需要了解一些产品参数来生成准确的图纸：

1. **滑梯尺寸**：长×宽×高是多少米？（如 12m × 8m × 6m）
2. **功能模块**：包含哪些组件？（如 3组滑梯、2个攀爬区、1个旋转盘）
3. **主要材质**：主体结构用什么材料？（如 镀锌钢管+LLDPE塑料）
4. **颜色方案**：主色调是什么？（如 蓝黄配色）
5. **目标场景**：安装在哪里？（如 幼儿园、社区公园）
6. **图片需求**：需要几张CAD图？几张3D渲染图？

**用户：** 尺寸12×8×6米，3组滑梯、2个攀爬区、1个秋千，镀锌钢管+LLDPE，蓝黄配色，安装在社区公园，需要全套6张图

**Agent：** 明白了，我将为您生成：
- 3张CAD技术图纸（平面图、正视图、细节图）
- 3张3D渲染效果图（主视觉、场景应用、多角度展示）

现在开始生成...
