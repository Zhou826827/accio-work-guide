# Logo 设计 (Logo Design)

## 场景说明

为用户设计原创 Logo 及品牌视觉识别系统，包括文字标（wordmark）、图形标（graphic logo）、徽章标（emblem）、吉祥物标（mascot）、字母组合标（monogram）、图标标志（icon mark）等多种 Logo 类型，以及后续的品牌应用 mockup。

核心原则：**商业安全优先**——所有输出必须为原创设计，严禁模仿现有品牌商标。

> **与 Logo Customization 的区别**：Logo Design 是从零设计原创 Logo；Logo Customization 是将已有 Logo 图片合成到商品上。如用户已有 Logo 且要求印/贴/合成到商品图上，请使用 **Logo Customization**（`references/logo-customization.md`）。

## 选择边界

**适用于：**
- Logo、文字标、图形标、徽章标、吉祥物标、字母组合标、图标设计
- 品牌视觉探索（多方向 Logo 方案）
- Logo 变体（深/浅底、单色、纯图标、横版/竖版锁定）
- 主 Logo 确定后的品牌应用 mockup

**不适用于：**
- 海报、Banner、产品 mockup、插画等非 Logo 主体任务 → 使用 `image-prompt-guide` 通用场景
- 产品线概念设计、多方案产品提案 → 使用 `ai-product-designer`
- 寻找现有产品/供应商/工厂 → 使用 `accio-product-supplier-sourcing`

## 应用方式：工作流

Logo 设计采用**五步工作流**，Agent 需按顺序执行。

### Step 1：理解品牌

收集设计必需上下文：
- 品牌名称及需包含的精确文字
- 行业、产品/服务、目标受众、价格定位
- 期望个性：premium / playful / technical / organic / heritage / bold 等
- 指定颜色、禁用颜色、使用场景、背景需求

> 若用户已提供足够上下文，直接推进。仅当 Logo 文字或业务背景缺失且无法推断时，才进行一次聚焦追问。

**搜索辅助**：仅当以下情况时使用 `web_search` / `web_fetch`：
- 用户点名某现有公司/产品并期望上下文感知设计
- 行业视觉语言实质影响设计方向
- 用户明确要求竞品感知或趋势感知设计

**用户提供现有 Logo**：先用 `see_image` 分析其当前视觉语言，再进行重设计。

### Step 2：确定设计方向

| 情况 | 行为 |
|------|------|
| 未指定数量 | 默认创建 **3 个差异化方向** |
| 指定数量 | 按需创建，每个方向风格明确不同 |
| 明确要求"只要一个" | 创建 1 个强方向，简短说明 |

推荐方向组合：
1. **行业对齐** — 品类内熟悉度高
2. **差异化** — 更具辨识度和记忆点
3. **高端/实验** — 高风险但独特

### Step 3：生成主 Logo

调用 `image_generate`，按下方 Prompt 模板构建 prompt。

### Step 4：衍生资产（仅在用户选定主 Logo 后）

若用户要求 mockup、规格、变体、包装、文具、标识或社交素材：
1. 先确认主 Logo 已选定
2. 使用 `image_edit`（`reference_images` 传入已选 Logo URL）或基于选定方向生成新图
3. 保持所有衍生资产与选定主 Logo 视觉一致

> ⚠️ 禁止在未选定主 Logo 前批量生成衍生资产——会导致品牌系统不一致。

### Step 5：呈现结果

每个方案包含：
- 方案标题
- 生成的 Logo 图片
- 一段简洁说明（概念、视觉选择、最佳适用场景）

附 2–3 个后续步骤建议：
- 优化选定方案
- 生成颜色/背景变体
- 创建应用 mockup
- 构建简版品牌套件

## Prompt 模板

```
Create an original [logo type] for "[brand name]", a [industry/product] brand for [target audience].
Concept: [symbolic idea and brand message].
Visual style: [style direction], [shape language], [typography direction].
Color and background: [palette], high contrast on [background].
Composition: clean centered logo, strong silhouette, readable at small sizes, balanced clear space.
Commercial safety: original logo design, commercially safe, must not resemble any existing brand logo or trademark.
```

**模板字段说明：**

| 字段 | 说明 |
|------|------|
| `[logo type]` | graphic logo / wordmark / monogram / emblem / mascot / icon mark |
| `[brand name]` | 精确品牌文字，用引号包裹 |
| `[style direction]` | 参考下方风格库选择 |
| `[shape language]` | 几何/有机/模块/线性... |
| `[typography direction]` | 衬线/无衬线/等宽/手写... |

## 风格库

以下风格作为设计方向锚点，非固定 prompt。

| 风格 | 适用行业 | 关键视觉原则 |
|------|----------|-------------|
| **Modern Minimal** | 科技、企业、建筑、专业服务 | 简单几何、强对齐、充裕留白、平面矢量、单色+一个强调色 |
| **Abstract Geometric** | 设计工作室、编辑品牌、AI/数据 | 解构形状、负空间、模块化、双色调、原创抽象符号 |
| **Heritage Vintage** | 咖啡、酒类、手工品、传统行业 | 徽章/纹章布局、克制手绘、低饱和墨色、少量装饰 |
| **Fashion / Beauty Light Luxury** | 化妆品、珠宝、时装、高端生活方式 | 精致衬线或优雅无衬线、粗细对比、编辑留白、奶油/黑/香槟配色 |
| **Modern Tech / Futuristic** | AI、软件、硬件、数据、网络安全 | 参数曲线、模块几何、精确切割、冷色中性+冷强调色 |
| **Cute Cartoon But Premium** | 食品、游戏、儿童、宠物、创作者品牌 | 圆形几何、友好但成熟比例、柔和低饱和色+一个亮强调色 |
| **Bold Geometric** | 运动、能源、大胆消费品 | 厚重稳定形状、强轮廓剪影、高对比、纯平面矢量 |
| **3D Luxury** | 高端时装、珠宝、腕表、奢侈生活 | 抛光/拉丝金属、倒角深度、电影光效、深色高对比背景 |

## 工具调用

| 阶段 | 工具 | task_type | 说明 |
|------|------|-----------|------|
| 生成主 Logo（Step 3） | `image_generate` | `complex` | Logo 设计复杂度高，默认使用 complex |
| 编辑/调整现有 Logo | `image_edit` | `simple_generation` 或 `complex_generation` | 根据修改复杂度选择 |
| 衍生资产（Step 4） | `image_edit` | `simple_generation` 或 `complex_generation` | 基于已选 Logo 进行合成/mockup |

## 注意事项

### 反侵权规则（强制）

生成任何 Logo 前，必须检查用户是否要求复制、克隆、模仿、仿制或微调现有品牌 Logo。

**若存在侵权风险：**
1. 明确告知不能直接复制或高度模仿现有 Logo
2. 提供基于抽象设计原则（色彩情绪、字体特征、几何节奏、品牌个性）的安全替代方案
3. 生成视觉上与现有商标明显不同的原创设计

**Prompt 中必须包含：**
```
Original logo design, commercially safe, must not resemble any existing brand logo or trademark.
```

**禁止行为：**
- 复制已知品牌的特定形状、图标、布局、字形或吉祥物细节
- 仅可提取抽象原则作为参考方向
- 用户提供的参考图仅作为情绪/风格输入，除非用户拥有该资产且明确要求编辑

### 输出质量检查

- [ ] 品牌文字准确无误
- [ ] 输出为原创且法律上与现有品牌明显不同
- [ ] 每个方案有不同的设计逻辑（非仅换色）
- [ ] 背景对比使 Logo 清晰可辨
- [ ] 已考虑小尺寸可读性
- [ ] 衍生 mockup 仅在主 Logo 选定后生成

### 多方案输出规则

- 多方案需分别生成独立图片（非拼在一张图上），方便用户单独使用
- 仅当用户明确要求"对比展示"时，才生成合并对比板
