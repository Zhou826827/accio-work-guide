# 工艺规格图 (Tech Pack)

## 场景说明

基于用户已有的商品图片，生成生产级技术包（Tech Pack），包含正交三视图标注、制造工艺图和组装爆炸图，辅以合规安全分析文字输出。适用于跨境电商卖家/OEM 下单前的生产技术交底场景。

核心原则：**商品主体 100% 一致**——产品外观（形状、颜色、纹理）不可改变，仅允许添加标注、尺寸线和工艺说明。

> **触发条件**：仅当用户**明确请求** tech pack / 技术图纸 / 规格图 / 工艺图 / 制作工艺图 / assembly diagram 时触发。普通产品设计或图像生成请求不走此场景。

## 应用方式：工作流（按需递进）

根据用户请求范围，按需输出不同图纸组合：

| 用户请求 | 输出动作 |
|---------|---------|
| "tech pack" / "dimension drawing" / "规格图" | 三视图（1 张组合图）+ 合规分析（文字） |
| + "manufacturing" / "process" / "工艺图" | 追加：制造工艺图（独立图片） |
| + "assembly" / "exploded" / "BOM" / "组装图" | 追加：组装爆炸图（独立图片） |

**执行顺序**：三视图 → 制造工艺图（如需）→ 组装爆炸图（如需）→ 合规安全分析（始终输出）

## Prompt 模板

### 图纸 1：三视图（始终必出）

**一张组合图**，包含 Front + Side + Top/Back 视图。

```
Create a tech pack for this [PRODUCT].

【SUBJECT PRESERVATION】
Keep product EXACTLY as source — do NOT change shape, color, texture. Only ADD annotations.

【LAYOUT】
ONE image with 3+ views: Front, Side, Top/Back on white background.

【ANNOTATIONS PER VIEW】
- Dimensions: H: __cm, W: __cm, D: __cm (with unit)
- Materials: specific grade (e.g., "600D Polyester")
- Surface finish: (e.g., "Matte", "Powder-coated")

【STYLE】
Technical drawing, thin outlines, title block with Product Name + Scale.
```

### 图纸 2：制造工艺图（仅按需）

**独立图片**，展示生产流程与工艺细节。

```
Create a manufacturing process diagram for this [PRODUCT].

【SUBJECT PRESERVATION】
Keep product appearance EXACTLY as source. Only ADD process flow, callouts, and annotations around it.

【LAYOUT】
Main product in center with numbered process steps around it (①②③...).

【CONTENT】
- Process Flow: Raw Material → Step 1 → Step 2 → ... → Finished
- Material specs at each stage
- Zoom callouts for critical craft (welding, stitching, molding)
- Tolerances and quality inspection points

【STYLE】
Technical illustration, numbered callouts, arrows showing sequence.
```

### 图纸 3：组装爆炸图（仅按需）

**独立图片**，展示零件拆解与组装关系。

```
Create an assembly diagram for this [PRODUCT].

【SUBJECT PRESERVATION】
Keep each component's appearance EXACTLY as source. Only SEPARATE components along axis to show assembly relationship.

【LAYOUT】
Exploded view with components separated along axis.
- Part numbers (①②③...) next to each component
- Dashed assembly lines connecting mating parts
- BOM table in corner

【BOM FORMAT】
| # | Part | Material | Qty |

【DETAIL CALLOUTS】
- Zoom into connection points (screws, snap fits, adhesive)
- Show fastener types and sizes

【STYLE】
Isometric view, consistent spacing between exploded parts.
```

### 固定拼接文案（所有图纸共用）

在上述任一 Prompt 末尾追加：

```
Keep the product 100% IDENTICAL to the source image — do NOT alter shape, color, or texture. Only ADD technical annotations, dimension lines, and callout labels.
```

## 合规安全分析（文字输出，始终附带）

基于产品类型和目标市场，提供文字分析覆盖：
- **适用法规**：目标市场强制性法规
- **认证要求**：必需/推荐的产品认证
- **材料合规**：限制物质、测试要求
- **标签要求**：原产地、成分、警告标识

### 产品类型快速参考

| 产品类型 | 关键标准 |
|---------|---------|
| 电子产品 | FCC, CE, UL, RoHS |
| 玩具/儿童用品 | CPSIA, ASTM F963, EN 71 |
| 食品接触 | FDA 21 CFR, EU 1935/2004 |
| 纺织/服装 | Flammability, OEKO-TEX |
| 家具 | BIFMA, CA TB 117 |

## 尺寸参考

| 产品 | 典型尺寸 |
|------|---------|
| 杯子 | H: 8–12cm, Ø: 7–10cm |
| 双肩包 | H: 40–50cm × W: 28–35cm × D: 12–18cm |
| 手提袋 | H: 35–45cm × W: 30–40cm |
| 蜡烛/香薰灯 | H: 15–30cm, Ø: 8–15cm |
| 台灯 | H: 30–50cm, Base Ø: 12–20cm |

## 工具调用

| 图纸类型 | 工具 | task_type |
|---------|------|-----------|
| 三视图 | `image_edit` | `complex_generation` |
| 制造工艺图 | `image_edit` | `complex_generation` |
| 组装爆炸图 | `image_edit` | `complex_generation` |

> Tech Pack 图纸包含多视图+密集标注，复杂度高，默认使用 `complex_generation`。

## 注意事项

- **商品主体一致性是核心要求**：产品的形状、颜色、纹理必须与原图完全一致，仅允许添加标注和辅助线
- **三视图必须合并为一张图**：Front + Side + Top/Back 在同一张图中呈现，不得分别单独输出
- **制造工艺图和组装图必须独立输出**：不得与三视图合并到一张图中
- **必须标注单位**：所有尺寸标注必须附带单位（cm / mm / inch）
- **组装图必含 BOM 表**：用户请求组装图时，必须包含零件清单（编号、名称、材料、数量）
- **前置条件**：用户必须已有商品图片。若用户未提供图片就请求 tech pack，需提示用户先上传商品图
- **仅做标注，不做重新设计**：严禁在 tech pack 流程中改变产品设计，仅对现有图片进行技术标注
- **合规分析始终附带**：无论用户是否单独要求，合规安全分析（文字）始终作为最后一部分输出
