# 细节图/卖点图 (Image Detail / Selling Point)

## 场景说明

基于商品原图对商品主体的局部细节进行放大展示，突出产品卖点（如材质纹理、工艺细节、功能结构等）。核心原则是**严格保持商品主体一致性**，仅对原图中已有的细节部分进行裁切放大或聚焦呈现，绝不生成原图中不存在的内容。

## 应用方式：拼接

在用户或 Agent 根据需求生成的细节描述 prompt **后面**拼接以下固定文案。

## Prompt 模板

### 用户/Agent 生成部分

由用户描述需要放大展示的细节区域或卖点，例如："Zoom in on the zipper and stitching details" 或 "放大展示鞋底的纹理和缓震结构"

### 固定拼接文案

```
Strictly based on the original image, zoom in and highlight the specified detail area of the product. Do NOT generate, add, or fabricate any content that does not exist in the original image. The product's shape, color, texture, and all visible features must remain exactly consistent with the original. Only crop and enlarge the detail area from the original product subject.
```

### 完整 prompt 结构

```
{用户/Agent 的细节描述 prompt} + Strictly based on the original image, zoom in and highlight the specified detail area of the product. Do NOT generate, add, or fabricate any content that does not exist in the original image. The product's shape, color, texture, and all visible features must remain exactly consistent with the original. Only crop and enlarge the detail area from the original product subject.
```

## 工具调用

- 工具：`image_edit`
- task_type：`simple_generation`

## 注意事项

- **商品主体一致性是核心要求**：生成的细节图必须与原图中的商品主体完全一致，不允许出现形变、颜色偏差或结构改变
- **严禁凭空生成内容**：只能对原图中已存在的细节进行放大展示，不得添加原图中没有的纹理、结构、标签或任何视觉元素
- 细节图与卖点图通用，均服务于突出商品局部特征的目的
- 用户/Agent 负责指定需要放大的细节区域（如拉链、缝线、材质表面、Logo、功能部件等）
- 固定文案用于约束输出严格基于原图，防止 AI 幻觉生成不存在的内容
