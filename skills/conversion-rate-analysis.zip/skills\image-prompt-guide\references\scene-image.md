# 场景图 (Scene Image)

## 场景说明

保持商品主体不变，为其生成或替换一个新的场景背景，营造生活化、使用场景化的视觉效果。

## 应用方式：拼接

在用户或 Agent 根据需求生成的场景描述 prompt **后面**拼接以下固定文案。

## Prompt 模板

### 用户/Agent 生成部分

由用户描述期望的场景，例如："Place the product on a modern kitchen countertop with warm morning light"

### 固定拼接文案

```
Keep the main product in the image exactly the same, retaining its original shape, texture, appearance and other visible product details.
```

### 完整 prompt 结构

```
{用户/Agent 的场景描述 prompt} + Keep the main product in the image exactly the same, retaining its original shape, texture, appearance and other visible product details.
```

## 工具调用

- 工具：`image_edit`
- task_type：根据场景复杂度选择 `simple_generation` 或 `complex_generation`

## 注意事项

- 商品的形状、纹理、外观及所有可见细节必须与原图完全一致
- 用户/Agent 负责描述场景内容（如背景环境、光线、氛围等）
- 固定文案用于约束商品主体不被修改
