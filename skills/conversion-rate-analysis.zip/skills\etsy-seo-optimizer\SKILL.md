---
name: etsy-seo-optimizer
description: >-
  Optimizes Etsy listing SEO using eRank data and Etsy search algorithm best practices. Covers keyword research, title/tag construction, and continuous performance monitoring. Use when optimizing Etsy search visibility, conducting keyword research, interpreting eRank metrics, or improving listing rankings.
workflow: |
  Follow the appropriate path based on listing status:
    New listing: 1. Keyword Research → 2. Title & Tag Construction → 3. Launch Checklist
    Existing listing (<90 days): Focus on images/description only, do NOT modify title/tags
    Existing listing (≥90 days): 1. Analyze Performance → 2. Identify Weak Keywords → 3. Iterative A/B Testing
enabled: true
---

# Etsy SEO Optimizer

Optimize the Etsy listing for $ARGUMENTS using a systematic, data-driven SEO methodology. SEO is an ongoing "scientific experiment" — continuous testing, monitoring, and adjustment — not a one-time task.

> **Scope:** For Etsy product discovery and idea generation, use `scenario-driven-product-scout`. For Amazon listing optimization, use `amazon-listing-expert`. For product trend timing, use `trend-stage-timing-analyzer`.

**Template Compliance:** Before generating the optimization checklist, read the template at `${CLAUDE_SKILL_DIR}/templates/listing_optimization_checklist.md` using `read_file` and follow its structure exactly. Include every section, fill all placeholders, and do not skip, reorder, or add sections.

---

## Workflow Decision Tree

Choose the appropriate workflow based on user needs:

**New Listing (Pre-Launch)**
- Conduct keyword research → Build title and tags → Validate using checklist

**Existing Listing (<90 Days)**
- Avoid frequent modifications — focus on image and description optimization only

**Existing Listing (≥90 Days)**
- Analyze keyword performance → Identify optimization opportunities → Iterative A/B testing

**Keyword Strategy Consultation**
- Analyze product category → Recommend keyword mix strategy → Provide case references

---

## Keyword Research Workflow

### Step 1: Use eRank for Keyword Research

Guide user to visit [eRank.com](https://www.erank.com) and use the Keyword Tool.

**Process:**
1. Start with a broad core term related to the product (e.g., "blanket", "wedding invitation", "ceramic mug")
2. Review eRank's suggested keywords and their metrics
3. Export or record key metrics for each keyword: Search Volume, Competition, CTR

### Step 2: Analyze Keyword Metrics

**Key Metrics to Evaluate:**
- **Search Volume**: Monthly estimated searches on Etsy
- **Competition**: Number of listings using this keyword
- **Search Volume / Competition Ratio**: Higher ratio = better opportunity

**Keyword Categories:**

**"Low-Hanging Fruit" (Priority Target)**
- Characteristics: Low to medium competition + medium search volume
- Best for: New shops, new listings, quick wins
- Example: Search Volume 2,000/month, Competition 5,000 listings

**"High-Hanging Fruit" (Long-Term Target)**
- Characteristics: High competition + high search volume
- Best for: Established shops, high-quality listings
- Example: Search Volume 50,000/month, Competition 100,000 listings

**Long-Tail Keywords (Supplementary Strategy)**
- Characteristics: Low competition + low to medium search volume
- Best for: Niche targeting, specific buyer intent
- Example: Search Volume 1,000/month, Competition 2,000 listings

### Step 3: Build Keyword List

Create a structured keyword list for the product:

**1-2 Superstar Keywords** (high search volume)
- Main traffic drivers; high competition but maximum exposure

**3-5 Low-Hanging Fruit Keywords** (medium search volume + low competition)
- Quick wins and steady traffic; easier to rank for new listings

**5-8 Long-Tail Keywords** (low search volume + low competition)
- Capture specific buyer intent; help with niche targeting and conversion

For detailed metric interpretation, see [erank_metrics_guide.md](references/erank_metrics_guide.md).

---

## Title Optimization

### Core Principles

**Exact Matching Priority**
- Etsy's algorithm gives higher weight to exact phrase matches
- Place complete "superstar keyword" phrases in the title
- Example: "chunky knit blanket" as a complete phrase ranks better than scattered words

**Broad Matching Support**
- Algorithm also considers related terms and concepts
- Including keyword components still provides value
- Example: "Knit Blanket - Chunky Wool Throw" still matches "chunky knit blanket"

**Keyword Position Weighting**
- Front-loaded keywords receive higher weight
- Place most important keywords in the first 20-30 characters

### Title Construction Formula

```
[Superstar Keyword] | [Low-Hanging Fruit 1] | [Low-Hanging Fruit 2] | [Long-Tail Keywords] | [Use Case/Gift]
```

**Best Practices:**
- Use all 140 characters available
- Include 1-2 complete superstar keyword phrases
- Add 2-3 low-hanging fruit keywords
- Include 1-2 long-tail keywords
- Use separators ("|" or "-") for readability
- Keep title natural and human-readable
- Avoid keyword stuffing

**Example:**
```
Chunky Knit Blanket | Hand Knit Merino Wool Blanket | Cozy Throw Blanket | Giant Knit Blanket | Home Decor Gift
```

For algorithm details, see [etsy_algorithm_guide.md](references/etsy_algorithm_guide.md).

---

## Tag Optimization

### Core Principles

**Use All 13 Tags**
- Etsy allows 13 tags per listing
- Each tag can contain multiple words (e.g., "chunky knit blanket")
- Do not split phrases into separate tags

**Tag Structure Strategy**

**First 5-7 Tags**: Repeat core keywords from title
- Reinforces relevance for important keywords
- Supports both exact and broad matching

**Last 6-8 Tags**: Add related keywords not in title
- Expand reach to additional search queries
- Include long-tail and attribute keywords

### Tag Construction Formula

**Core Tags (from title):**
1. Main superstar keyword
2. Secondary superstar keyword
3-7. Low-hanging fruit keywords from title

**Supplementary Tags (not in title):**
8-10. Additional long-tail keywords
11-12. Product attribute keywords (e.g., "handmade", "custom", "personalized")
13. Use case or gift keyword (e.g., "wedding gift", "home decor")

**Example:**
```
1. chunky knit blanket
2. knit blanket
3. merino wool blanket
4. hand knit blanket
5. chunky throw blanket
6. giant knit blanket
7. cozy knit blanket
8. wool throw blanket
9. handmade blanket
10. knitted blanket
11. chunky blanket
12. handmade throw
13. home decor gift
```

---

## Launch & Quality Score Building

### Understanding the 60-90 Day Period

**Algorithm Data Collection:**
- New listings need 60-90 days for Etsy's algorithm to collect sufficient data
- During this period, algorithm tests listing performance across different search queries
- Quality Score is established based on: CTR, conversion rate, favorites, cart adds, shop performance

**Best Practices During This Period:**
- **Do NOT** frequently modify title and tags (interferes with data collection)
- **DO** focus on optimizing images, description, pricing, customer service
- **DO** monitor views, clicks, favorites, and sales
- **DO** be patient and let algorithm establish Quality Score

**After 60-90 Days:**
- Listing will have stable Quality Score
- Algorithm will show listing for relevant search queries based on established performance
- Now safe to iterate and optimize based on data

For detailed algorithm explanation, see [etsy_algorithm_guide.md](references/etsy_algorithm_guide.md).

---

## Continuous Optimization

### Monthly Monitoring Workflow

**Step 1: Review Performance Data**
- Use eRank or Etsy Stats to check keyword rankings
- Monitor search volume and competition changes
- Track CTR, conversion rate, and sales by keyword

**Step 2: Identify Optimization Opportunities**
- Keywords with high impressions but low CTR: Optimize images/title appeal
- Keywords with high clicks but low conversion: Optimize description/pricing
- Keywords with declining search volume: Replace with trending alternatives
- Keywords with increasing competition: Consider long-tail variations

**Step 3: Implement Changes**
- Change only ONE variable at a time (title OR tags, not both)
- Document changes with date and reason
- Wait 2-4 weeks to observe impact before next change

**Step 4: A/B Testing Strategy**
- Test new keywords one at a time
- Compare performance before and after changes
- Keep successful changes, revert unsuccessful ones

### Seasonal and Trend Adjustments

**Monitor Trends:**
- Use eRank Trend Buzz to identify seasonal keywords
- Adjust keywords 1-2 months before peak season
- Example: Add "Christmas gift" tags in October-November

**Learn from Competitors:**
- Analyze top-ranking competitors' titles and tags
- Identify successful keyword patterns
- Adapt strategies while maintaining uniqueness

---

## Practical Examples

For detailed case studies across product categories, see [keyword_strategy_examples.md](references/keyword_strategy_examples.md).

**Quick Reference Examples:**

**Hand-Knit Blanket**
- Title: "Chunky Knit Blanket | Hand Knit Merino Wool Blanket | Cozy Throw Blanket | Giant Knit Blanket | Home Decor Gift"
- Strategy: Lead with high-volume "chunky knit blanket", add material "merino wool", include use case "home decor gift"

**Custom Wedding Invitation**
- Title: "Modern Wedding Invitation Template | Printable Wedding Invites | Custom Minimalist Wedding Invitation | Digital & Printed"
- Strategy: Lead with style "modern", emphasize format "printable" and "digital", include customization

**Handmade Ceramic Mug**
- Title: "Handmade Ceramic Mug | Pottery Coffee Mug | Unique Artisan Ceramic Coffee Cup | Gift for Coffee Lover"
- Strategy: Lead with craft "handmade ceramic", add product type "pottery", include gift angle

---

## Optimization Checklist

Before generating the checklist, read the full template at `${CLAUDE_SKILL_DIR}/templates/listing_optimization_checklist.md` and follow its complete structure. Do NOT summarize or abbreviate.

**Quick Checklist:**
- Keyword research completed using eRank
- Title includes 1-2 superstar keywords (complete phrases)
- Title uses ~140 characters
- All 13 tags filled with relevant keywords
- First 5-7 tags repeat title keywords
- Last 6-8 tags add supplementary keywords
- Images optimized (high quality, clear, multiple angles)
- Description detailed and keyword-rich
- Ready to wait 60-90 days for Quality Score establishment

---

## Additional Resources

- [etsy_algorithm_guide.md](references/etsy_algorithm_guide.md) — Etsy search algorithm, exact vs broad matching, Quality Score
- [erank_metrics_guide.md](references/erank_metrics_guide.md) — eRank metrics, search volume, competition, keyword strategies
- [keyword_strategy_examples.md](references/keyword_strategy_examples.md) — Case studies and title/tag examples by product category
- `${CLAUDE_SKILL_DIR}/templates/listing_optimization_checklist.md` — Full optimization checklist template (read via `read_file`)
