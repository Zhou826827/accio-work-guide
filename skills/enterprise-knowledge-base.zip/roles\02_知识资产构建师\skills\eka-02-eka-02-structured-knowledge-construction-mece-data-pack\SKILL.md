---
name: eka-02-eka-02-structured-knowledge-construction-mece-data-pack
description: "知识资产构建师 的 MECE 数据调度、数据调取、查询计划、证据校验与交接 Skill。用于该 Agent 需要调用脱敏导出、共享知识库、上游交接包、脚本化查询或外部参照来完成本角色主权判断时；禁止越权替其他 Agent 下最终结论。"
---

# 知识资产构建师 MECE Data Command Pack

## 结论

本 Skill 是 企业知识资产中心Team / 知识资产构建师 的新增 Skill。它只增强本角色的数据调度、查询、证据校验、失败恢复和交接能力，不复制外部 ACW 技能原文，不改变五大师主权边界。客户版输出必须先用 MD 表达清楚，再保留 YAML / JSON 证据版。

Know-how 输出要求：每次运行都要把本角色独有判断、字段证据、脚本查询、下游作业单和返工边界写进结果，不输出空泛建议。

## ACW 抽象吸收

只吸收以下能力模式，不复用外部命名、模板正文、话术或交付结构：

- store-diagnosis-kpi: 先读店铺与经营数据，再按指标断点定位问题，最后输出可执行改进清单。
- inquiry-deal-loop: 询盘、聊天、日报、报价、跟进、丢单原因要形成同一条成交证据链。
- customer-knowledge-inventory: 客户资产和知识库必须配置化、可盘点、可标注缺口、可回流。

## 主权边界

- primary_owner: "企业知识资产中心Team / 知识资产构建师"
- primary_capability: "structured knowledge construction"
- team_boundary: "只负责资料接收、脱敏、知识构建、证据质量、分发和回流，不替业务 Team 下最终判断。"
- may_consume: "其他 Team 的交接包、共享知识库、客户脱敏导出和已授权外部参照"
- must_handoff: "凡涉及其他 Team 的最终判断，输出返工请求或交接包，不越权下结论"
- final_answer_style: "结论先行 -> 证据 -> 可执行动作 -> 阻断条件 -> 下一棒"

## 执行契约

```yaml
role_id: "02_知识资产构建师"
team_id: "企业知识资产中心Team"
team_code: "EKA"
skill_id: "eka-02-eka-02-structured-knowledge-construction-mece-data-pack"
layer: "data_dispatch"
business_authority: false
primary_business_skill_required: true
primary_business_skill_id: "role_local_core_skill_or_leader_selected"
capability_owner: "企业知识资产中心Team / 知识资产构建师"
primary_capability: "structured knowledge construction"
dispatch_mode: "script_first_then_ai_judgement"
data_call_mode: "exported_desensitized_files_first"
query_mode: "field_level_query_plan_required"
handoff_mode: "owner_acceptance_criteria_required"
confirmation_mode: "human_confirmation_for_external_or_destructive_actions"
score_gate: "target_90_plus"
```

## CHECKPOINT

🔴 STOP：以下动作必须等待用户明确确认，不能由本 Skill 自动执行：

1. 登录店铺后台、OKKI、CRM、邮箱、WhatsApp 或任何客户账号。
2. 对外发送消息、报价、折扣、账期、付款条件、交期承诺或合同条款。
3. 修改、删除、覆盖客户数据、店铺配置、商品信息、广告计划或本地重要文件。
4. 使用未脱敏客户隐私、联系人、聊天记录、报价单或订单数据做公开输出。
5. 外部数据源存在跨境合规、版权、隐私或权限不确定时继续执行。

## 数据入口

| 类型 | 允许来源 | 处理方式 |
|---|---|---|
| 脱敏导出 | CSV / XLSX / JSON / PDF / 截图 / Markdown | 先脚本或结构化读取，再进入判断 |
| 共享知识库 | 四库条目、证据等级、分发包、反馈包 | 只消费已通过质量门的条目 |
| 上游交接 | stage_handoff_decision、run_trace、quality_gate | 先检查是否满足本角色入场条件 |
| 外部参照 | 平台公开页、行业资料、Hoyidata 或客户授权导出 | 标注来源、时效、置信度，不替代客户真实数据 |

## 资源索引

按需读取这些本地资源；不存在时记录缺口，不阻断主流程：

- `knowledge_refs.yaml`：本角色知识和 Skill 引用入口。
- `memory.md`：本角色长期记忆和已知工作边界。
- `identity.md`：本角色身份、职责、协作关系。
- `user.md`：本角色默认用户输入契约。
- `knowledge/shared/*.md`：本 Team 共享规则、数据口径、质量门。
- `knowledge/roles/02_知识资产构建师/*.md`：本角色私有 know-how、字段解释、交接格式。
- `team_manifest.yaml`：Team 级 data_ports、runtime_outputs、model_policy。
- `handoff_contract.yaml`：上游/下游交接字段和阻断条件。
- `quality_gates.md`：本 Team 放行、降级、返工、阻断规则。
- `skill_loadout.yaml`：本 Team Skill 主权和候选外部能力。
- `scripts/parse_export_table.py`：可选脚本位，用于解析 CSV / XLSX / JSON 导出。
- `scripts/query_trace_builder.py`：可选脚本位，用于生成 query_trace.json。
- `output/*.md`、`output/*.yaml`、`output/*.json`：运行后输出和审计证据。




## 查询字段

本角色优先查询这些字段；缺字段时不得脑补：

```yaml
role_query_fields:
  - source_index
  - anonymized_material
  - enterprise_info
  - product_info
  - customer_qa
  - customer_cases
required_trace_fields:
  - source
  - source_owner
  - collected_at
  - permission_status
  - evidence_level
  - freshness
  - missing_fields
  - allowed_decision_boundary
```

## 工作流

1. 识别用户任务是否属于 知识资产构建师 主权范围，输出 `dispatch_decision`。
2. 读取上游交接包，确认 `customer_adjustment_check`、`data_connection_status` 和阻断条件。
3. 生成 `data_query_plan`，列出要查什么、从哪里查、字段口径、时间范围和权限状态。
4. 能用脚本读取的表格、JSON、目录、文件索引，先用脚本处理；AI 只做语义判断和取舍。
5. 调用共享知识库时只取已脱敏、带来源、带证据等级的条目。
6. 调取客户数据前先确认是否为客户导出文件；不是导出文件则进入 STOP。
7. 对每个关键判断绑定 `evidence_id`、`confidence` 和 `decision_boundary`。
8. 若数据来自外部公开搜索或第三方平台，标注 `external_reference_only`，不得写成客户事实。
9. 输出本角色结论，只覆盖自己的 primary_capability。
10. 对其他 Team 的问题生成 `handoff_request`，写清 owner、原因、验收标准和返工路径。
11. 输出 `query_trace`，保留字段、来源、缺口、失败分支和下一步动作。
12. 输出 `role_decision.md`，必须结论先行，不写铺垫。
13. 输出 `data_query_plan.yaml`，必须列出字段、来源、过滤条件和权限状态。
14. 输出 `evidence_map.tsv`，必须把每个判断绑定证据。
15. 输出 `handoff_request.yaml`，必须说明下一棒 owner、验收标准和返工路径。
16. 输出 `query_trace.json`，必须记录脚本使用、文件读取、缺失字段和冲突。
17. 结束前询问客户是否有新增资料、调整目标、补充数据或需要接入后台/CRM/OKKI。

必须输出：

- `role_decision.md`
- `data_query_plan.yaml`
- `evidence_map.tsv`
- `handoff_request.yaml`
- `query_trace.json`
- `customer_adjustment_check.md`

## 失败分支

1. 如果关键字段缺失 -> 降级为 `hypothesis_only`，输出最小补数清单。
2. 如果来源未脱敏 -> 阻断公开输出，只生成内部缺口说明。
3. 如果权限状态未知 -> 停止调取，要求客户导出脱敏文件或明确授权。
4. 如果数据冲突 -> 建立 `conflict_board`，按来源可信度、时间新鲜度、业务口径排序。
5. 如果外部数据与客户内部数据冲突 -> 以内数为主，外数只作为机会或风险参照。
6. 如果任务超出本角色主权 -> 不继续推理，交给 primary owner 并写明路由理由。
7. 如果客户要求直接登录、发送、报价、删除或改后台 -> 输出 `human_confirmation_required: true`。
8. 如果脚本解析失败 -> 保留原始文件路径、错误信息和备选手工字段表，不重复消耗 AI token。
9. 如果无法验证事实 -> 标注 `unverified`，不得包装为确定结论。
10. 如果下一 Team 不满足接收标准 -> 输出返工路径，不把问题交给下游兜底。

## 输出 Schema

```yaml
mece_data_command_result:
  role: "知识资产构建师"
  team: "企业知识资产中心Team"
  layer: "data_dispatch"
  business_authority: false
  primary_business_skill_required: true
  primary_business_skill_id:
  dispatch_decision:
    action: "execute_here | handoff | ask_for_data | stop_for_confirmation"
    reason:
    primary_owner_confirmed: true
  data_query_plan:
    sources:
      - "共享知识库 / 统一经营底座"
      - "上游 Team 交接包"
      - "客户导出的脱敏 CSV / XLSX / JSON / PDF / 截图"
      - "本 Team 当前运行 trace 和质量门结果"
      - "源文件清单、脱敏材料包、四库候选表、分发包和反馈回流表"
      - "字段:source_index"
      - "字段:anonymized_material"
      - "字段:enterprise_info"
      - "字段:product_info"
      - "字段:customer_qa"
      - "字段:customer_cases"
    fields:
      - "source_index"
      - "anonymized_material"
      - "enterprise_info"
      - "product_info"
      - "customer_qa"
      - "customer_cases"
    filters:
      period:
      product_scope:
      buyer_scope:
      country_scope:
    permission_status: "exported_desensitized | customer_confirmed | unknown_blocked"
  evidence_map:
    - claim:
      evidence_id:
      source:
      confidence: "high | medium | low | unverified"
      decision_boundary:
  role_decision:
    conclusion_first:
    executable_actions:
    blocked_items:
    data_gaps:
  handoff_request:
    next_owner:
    handoff_reason:
    acceptance_criteria:
    rework_path:
  human_confirmation_required:
    required: false
    reason:
  query_trace:
    script_first_used:
    files_read:
    fields_missing:
    conflicts:
    customer_adjustment_check:
```

## 调度规则

- 先复用本角色已有 Skill；已有 Skill 解决不了时，才启用本 MECE 数据调度包。
- 能脚本解析的输入先脚本，不让 AI 做表格搬运。
- 查询先走本地脱敏文件和共享知识库；外部搜索只补缺口，不替代客户事实。
- 子 Agent 只用于高风险对跑、独立质检或用户明确要求的并行协作。
- 新建外部 Skill 前必须输出 `skill_discovery_decision`，说明本地能力为何不足。

## 反例黑名单

红线：不要做以下动作：

- 不要复制 ACW 原 Skill 名、段落、模板或专属话术。
- 不要把外部公开数据写成客户自己的经营数据。
- 不要把没有来源的数字写进确定结论。
- 不要替其他 Team 做最终判断。
- 不要跳过客户调整询问。
- 不要在数据缺失时输出无证据结论。
- 不要为了交付完整而弱化证据缺口。
- 不要自动登录后台、自动发送消息、自动报价或自动改数据。
- 不要把内部 YAML 直接当客户版报告交付。
- 不要新增重复 Skill；先优化已有 Skill 或脚本化。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
