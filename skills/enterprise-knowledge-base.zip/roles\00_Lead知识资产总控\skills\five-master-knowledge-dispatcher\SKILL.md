---
name: five-master-knowledge-dispatcher
description: "把通过质量门的四库知识按经营定位、选品优化、内容表达、流量运营、业务成交五大师任务打包，并定义使用边界和回流要求。"
---

# Five Master Knowledge Dispatcher

## 结论

本 Skill 只负责共享知识库的分发和回流要求，不替任何业务 Team 下最终判断。

## 必读知识

- `knowledge/roles/00_Lead知识资产总控/05_五大师分发与回流规则.md`
- `knowledge/roles/00_Lead知识资产总控/06_输出模板与最终交付格式.md`
- `agent-ready/Teams/_shared/01_五大师Leader调度与共享知识库协议.md`

## 输入

```yaml
approved_library_items:
  enterprise_info: []
  product_info: []
  customer_qa: []
  customer_case: []
five_master_usage_needs:
  business_positioning_department:
  product_optimization_department:
  content_expression_department:
  traffic_operation_department:
  deal_conversion_department:
  deal_feedback_and_repurchase_signal:
evidence_gaps:
```

## 流程

1. 识别每条知识最适合服务哪个五大师 Team。
2. 按任务打包，不按资料来源打包。
3. 写清 `allowed_usage` 和 `forbidden_usage`。
4. 标注证据缺口、脱敏状态和权限边界。
5. 为每个 Team 定义回流要求。
6. 判断默认进入经营定位，还是按客户目标直接分发到选品、内容、运营或成交。
7. 输出 `five_master_distribution_plan` 和 `stage_handoff_decision`。

## 输出

```yaml
five_master_distribution_plan:
  business_positioning_department:
    knowledge_items: []
    allowed_usage: []
    forbidden_usage: []
    feedback_required: []
  product_optimization_department:
    knowledge_items: []
    allowed_usage: []
    forbidden_usage: []
    feedback_required: []
  content_expression_department:
    knowledge_items: []
    allowed_usage: []
    forbidden_usage: []
    feedback_required: []
  traffic_operation_department:
    knowledge_items: []
    allowed_usage: []
    forbidden_usage: []
    feedback_required: []
  deal_conversion_department:
    knowledge_items: []
    allowed_usage: []
    forbidden_usage: []
    feedback_required: []
  stage_handoff_decision:
    default_next_team: "经营定位部"
    recommended_next_team:
    routing_reason:
    ready_for_next_team:
    blocked_reason:
    next_team_acceptance_criteria: []
```

## 质量门

必须失败：

- 分发包没有目标 Team。
- 分发包没有使用场景。
- 分发包没有回流要求。
- 未通过质量门的知识被分发。
- 内部资料被用于对外内容。
- 没有判断下一 Team 或缺少 `routing_reason`。

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "00_Lead知识资产总控"
  skill: "five-master-knowledge-dispatcher"
  score_before_upgrade: 72.9
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "知识库 / 脱敏 / 分发:企业知识资产中心Team,经营定位:经营定位部,内容表达 / 视觉 Brief:内容表达部,SKU / 产品组合:选品优化部,流量 / SEO / 投放:流量运营部,询盘 / 报价 / 成交:业务成交部,质量门 / 质检:role-local"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "00_Lead知识资产总控"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。


<!-- LEADER_FINAL_CLOSING_PROTOCOL_V1:skill -->
## 最终客户收口协议

本 Skill 只要产出阶段报告、客户版最终报告或 Leader 汇总结果，结尾必须输出“三选一客户确认”。缺失该确认区时，本次交付视为未完成。

### 客户可见收口模板

```md
## 你现在只需要选一个下一步

我的建议：先选【交接下一部门】，因为【知识底座的价值在于分发给对应业务大师；资料不足时必须先回到资料补充。】

1. 修改本报告：你告诉我要改哪里，我先修正结论和作业单。
2. 交接下一部门：我会把本轮结论整理成交接包，交给【对应五大师 / 资料接收与托管师】继续做。
3. 保存归档：我会把本轮报告、交接包、缺口清单保存到工作目录，并回流共享知识库。

如果涉及登录后台、OKKI/CRM/邮箱、发送消息、报价、修改或删除数据，我会先单独向你确认授权。
```

### 机器交接字段

输出交接报告时必须包含：

```yaml
customer_next_action_prompt:
  required: true
  title: "你现在只需要选一个下一步"
recommended_next_action: "交接下一部门"
next_action_options:
  - "修改本报告"
  - "交接下一部门"
  - "保存归档"
recommended_next_team: "对应五大师 / 资料接收与托管师"
handoff_ready: false
revision_allowed: true
archive_to_workspace_allowed: true
human_confirmation_required:
  required: false
  triggers:
    - "登录后台"
    - "OKKI/CRM/邮箱"
    - "发送消息"
    - "报价"
    - "修改或删除数据"
```

### 路由规则

- 资料不足时，先交给资料接收与托管师补资料和权限。
- 资料通过质量门后，按任务分发给经营定位部、选品优化部、内容表达部、流量运营部或业务成交部。
- 成交、丢单、履约和复购反馈默认回流共享知识库。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
