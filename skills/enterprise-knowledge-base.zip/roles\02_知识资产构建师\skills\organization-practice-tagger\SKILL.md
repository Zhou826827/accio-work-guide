---
name: organization-practice-tagger
description: "从案例、问答、访谈和复盘中沉淀组织实践标签，将方法经验内沉到 reusable_method、recommended_usage 和 practice tags。"
---

# Organization Practice Tagger

## 使用场景

当客户案例、问答、老板经验、销售复盘中出现可复用方法或判断标准时使用。

本 Skill 负责内部方法沉淀，不创建对外第五库。

## 必读知识

先读取：

- `knowledge/roles/02_知识资产构建师/06_组织实践标签与方法内沉规则.md`
- `前段ACCIO资料库分类整理/优秀商业访谈师特质.md`

## 输入

```yaml
customer_qa_candidates:
customer_case_candidates:
interview_notes:
sales_review:
source_index:
```

## 流程

1. 识别场景、流程、角色、判断、动作、标准、机制、反馈。
2. 判断方法经验应内沉到案例、问答还是组织实践标签。
3. 标记 `verified | needs_validation | internal_only`。
4. 保留来源 ID。
5. 输出组织实践标签和方法内沉建议。

## 输出

```yaml
organization_practice_output:
  organization_practice_tags: []
  reusable_method_candidates: []
  recommended_usage_updates: []
  needs_validation_methods: []
```

## 质量门

必须标记 `needs_validation`：

- 只有口述，没有案例。
- 只有一次销售经验。
- 没有明确客户场景。

必须标记 `internal_only`：

- 涉及内部报价策略。
- 涉及客户隐私。
- 涉及不适合对外公开的谈判过程。

## 边界

不要创建第五库。
不要输出课程方法论包装。
不要把内部经验直接写成公开内容。

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "02_知识资产构建师"
  skill: "organization-practice-tagger"
  score_before_upgrade: 69.6
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "知识库 / 脱敏 / 分发:企业知识资产中心Team"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "02_知识资产构建师"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。

<!-- ACCIO_85_RESOURCE_RECOVERY_UPGRADE_V2 -->

## Resource Binding And Recovery Gate

本段只处理 85 分门槛缺口：资源绑定、失败恢复、run trace 和交付验收。它不新增业务主权，不改变原 Skill 的职责范围。

### Resource Binding

执行前必须按需读取或生成这些资源索引：

- knowledge_refs.yaml：确认本角色私有知识、共享知识和本地 skills 可达。
- team_manifest.yaml：确认 data_ports、runtime_outputs、leader_governance 和 permission_policy。
- workflow.md：确认本 Team 的阶段流程、worker 回收路径和 agent-ready/Teams/_shared_workspace/runs/<run-id>/ 目录规范。
- handoff_contract.yaml：确认 required_outputs、block_if、next_team_acceptance_criteria 和 human_confirmation_required。
- quality_gates.md：确认 redline、blocked、test_only、ready_to_handoff 的判定标准。
- skill_loadout.yaml：确认本 Skill 与同 Team 其他 Skill 不重复。
- agent-ready/Teams/_shared_workspace/runs/<run-id>/role_reports/organization-practice-tagger.md：写入角色判断报告。
- agent-ready/Teams/_shared_workspace/runs/<run-id>/handoff/stage_handoff_decision.yaml：写入下一棒交接字段。
- agent-ready/Teams/_shared_workspace/runs/<run-id>/qa/organization-practice-tagger_quality_gate.yaml：写入质量门结果。
- agent-ready/Teams/_shared_workspace/runs/<run-id>/data/organization-practice-tagger_evidence_index.tsv：写入证据索引。
- agent-ready/Teams/_shared_workspace/runs/<run-id>/data/organization-practice-tagger_run_trace.json：写入可复盘执行轨迹。

### Additional Failure Recovery

1. 如果 knowledge_refs.yaml 读取失败 -> fallback 到 team_manifest.yaml 的 knowledge_root，并记录 missing_reference。
2. 如果 team_manifest.yaml 缺 data_ports -> fallback 输出 data_gap，不进入确定结论。
3. 如果 workflow.md 缺输出目录 -> fallback 使用 agent-ready/Teams/_shared_workspace/runs/<run-id>/role_reports/ 和 handoff/ 标准目录。
4. 如果 handoff_contract.yaml 缺 next_team_acceptance_criteria -> fallback 生成临时验收标准并要求 Leader 审核。
5. 如果 quality_gates.md 缺阻断规则 -> fallback 为 blocked_until_quality_gate_defined。
6. 如果 skill_loadout.yaml 显示能力重复 -> fallback 为 skill_curator_review_required。
7. 如果 role_reports/*.md 未生成 -> fallback 为 no_customer_delivery，只保留内部草稿。
8. 如果 stage_handoff_decision.yaml 未生成 -> fallback 为 no_next_team_handoff。
9. 如果 evidence_index.tsv 为空 -> fallback 为 hypothesis_only。
10. 如果 run_trace.json 缺失 -> fallback 为 verification_incomplete。

### Acceptance Gate

交付前必须同时满足：

1. conclusion_first 已写入客户可读结论。
2. evidence_index.tsv 至少包含 source、field、confidence、owner 四列。
3. role_reports/*.md 与 handoff/*.yaml 分离。
4. qa/*.yaml 明确 pass、test_only、blocked 或 return_to_upstream。
5. next_customer_questions 明确客户还要补什么资料。
6. human_confirmation_required 覆盖登录、发送、报价、修改、删除、外部能力启用。
7. shared_knowledge_feedback 写明是否回流知识库。

### Do Not Extend Scope

- 不因补强资源绑定而扩大本 Skill 职责。
- 不把 Resource Binding 写成客户第一层正文。
- 不用 run_trace 代替业务证据。
- 不用质量门通过代替真实 full_test。
- 不把 test_only 写成 ready_to_execute。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
