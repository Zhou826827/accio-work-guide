---
name: acio-demo-loop-orchestrator
description: "现场演示企业知识库到 aCIO 闭环时使用：固定资料进入、四库主表、内容应用、询盘转化、回流记录的演示顺序和质量门。"
---

# aCIO Demo Loop Orchestrator

## 使用场景

当用户要在讲课、培训、客户现场或售前演示中展示 Accio/aCIO 闭环时使用。

本 Skill 不负责编造客户资料，也不直接做真实后台提交。它负责把演示稳定地编排成：

```text
资料包 -> 企业知识库 -> 四库 + 五张主表 -> 内容应用 -> 询盘转化 -> 回流记录
```

## 必读

先读取：

- `output/11_Accio现场演示与aCIO闭环实现方案.md`
- `output/Accio现场演示样例包/README.md`
- `knowledge/roles/00_Lead知识资产总控/08_内容资产生产线与应用路由.md`

## 输入

```yaml
demo_mode: "local_sample/live_client/hybrid"
source_package_path: ""
audience: "老板/外贸负责人/业务/运营/混合"
demo_goal: "讲逻辑/跑样例/客户售前/内部培训"
available_permissions:
  browser: false
  connectors: []
  mcp: []
privacy_requirement: ""
```

## 标准演示顺序

1. 先确认资料包：公司资料、产品表、询盘、报价规则、交易反馈。
2. 调用企业知识库，生成四库摘要。
3. 调用五张主表构建：产品、客户询盘、报价、交付、合规。
4. 调用内容应用路由：商详、FAQ、品宣、询盘素材。
5. 调用询盘转化闭环：评分、首响、人工确认、跟进。
6. 输出回流记录：新问题、新异议、新案例线索、新交易数据。
7. 输出老板版讲解：这一步解决什么经营问题。

## 输出

```yaml
demo_loop_output:
  status: "ready/pass_with_gap/blocked"
  demo_path:
    source_package:
    knowledge_base_foundation:
    master_tables:
    content_application:
    inquiry_conversion:
    feedback_loop:
  visible_results:
    - "四库摘要"
    - "五张主表草稿"
    - "FAQ with question/answer/application_scenarios"
    - "结构化商详 Brief"
    - "询盘评分与英文首响"
    - "回流记录"
  missing_inputs: []
  risk_controls: []
  talk_track: ""
```

## 质量门

必须 `blocked`：

- 没有资料包路径。
- 没有隐私边界。
- 只生成文案，没有生成四库或主表。
- FAQ 没有 `question / answer / application_scenarios`。
- 没有展示回流记录。

允许 `pass_with_gap`：

- 真实 Browser/Connectors/MCP 未接入，但本地样例包可以完整演示。
- 交易数据是样例数据，但已标注 demo。
- 后台写入动作只展示草稿和审批，不真实提交。

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "00_Lead知识资产总控"
  skill: "acio-demo-loop-orchestrator"
  score_before_upgrade: 73.9
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "知识库 / 脱敏 / 分发:企业知识资产中心Team,内容表达 / 视觉 Brief:内容表达部,询盘 / 报价 / 成交:业务成交部,质量门 / 质检:role-local"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "00_Lead知识资产总控"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
