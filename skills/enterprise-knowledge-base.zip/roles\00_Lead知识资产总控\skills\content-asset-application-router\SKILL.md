---
name: content-asset-application-router
description: "把企业知识库的四库知识进一步路由到品牌品宣、结构化商详、FAQ、询盘跟进、营销推广、社媒和独立站等内容应用场景。"
---

# Content Asset Application Router

## 使用场景

当用户要求：

- 梳理企业内容体系。
- 用 Accio 自动化整理内容知识库。
- 把语音沟通、老板访谈、客户访谈、线下交流变成结构化内容。
- 生成品牌内容、对外品宣、结构化商详、FAQ、询盘跟进、社媒或独立站内容。
- 判断知识库搭好后如何重复调用。
- 把五张主表、询盘事实、报价规则和交易反馈转成内容应用包。

必须使用本 Skill。

## 必读知识

先读取：

- `knowledge/roles/00_Lead知识资产总控/08_内容资产生产线与应用路由.md`
- `knowledge/roles/00_Lead知识资产总控/02_四库建设策略与字段门.md`
- `knowledge/roles/00_Lead知识资产总控/04_证据隐私质量门.md`
- `output/08_内容体系知识库与Accio自动化梳理蓝图.md`
- `output/11_Accio现场演示与aCIO闭环实现方案.md`

## 输入

```yaml
source_assets:
  - type: "document/voice/chat/interview/backend"
    path_or_description:
business_goal:
master_tables:
  Product_Master:
  Customer_Inquiry_Fact:
  Quote_Rule:
  Delivery_Rule:
  Compliance_Cert_Table:
content_targets:
  - "alibaba_knowledge_base"
  - "structured_product_detail"
  - "faq_pack"
  - "inquiry_followup"
  - "brand_promotion"
  - "marketing_content"
  - "social_independent_site"
privacy_requirement:
```

## 流程

1. 先判断资料是否只够做四库，还是已经能做内容应用包。
2. 对每类资料打 `source_format`：文档、语音转写、线下访谈、聊天记录、后台数据。
3. 识别能形成哪类内容资产：企业实力、品牌品宣、产品表达、买家问题、信任证据、场景方案、交易反馈。
4. 要求构建师补齐 `question / answer / application_scenarios`。
5. 给每条内容资产写 `content_application_route`。
6. 质检公开边界：公开、内部、待验证。
7. 若有五张主表，必须把产品事实、报价边界、证书、交期和交易反馈写入内容应用依据。
8. 输出可交给客户理解的应用路线图。

## 输出

```yaml
content_asset_router_output:
  status: "ready/pass_with_gap/blocked"
  source_summary:
  content_asset_layers:
    enterprise_strength: []
    brand_promotion: []
    product_expression: []
    buyer_qa: []
    trust_evidence: []
    scenario_solution: []
    transaction_feedback: []
  application_routes:
    alibaba_knowledge_base: []
    structured_product_detail: []
    faq_pack: []
    inquiry_followup: []
    brand_promotion: []
    marketing_content: []
    social_independent_site: []
  master_table_usage:
    Product_Master: []
    Customer_Inquiry_Fact: []
    Quote_Rule: []
    Delivery_Rule: []
    Compliance_Cert_Table: []
  missing_inputs:
  public_or_internal_boundary:
  next_actions:
```

## 质量门

必须 `blocked`：

- 没有来源。
- 没有隐私边界。
- 语音资料只有转写，没有结构化抽取。
- FAQ 没有具体问题、答案、应用场景。
- 品宣内容没有证据支撑。
- 客户案例没有公开权限却要对外发布。

允许 `pass_with_gap`：

- 可先生成内部草稿，但缺证书、交易数据或公开授权。
- 可以生成商详 Brief，但缺图片或 SKU 参数。
- 可以生成 FAQ 初稿，但答案需要销售确认。

## 边界

不要承诺：

- 已自动接入阿里后台。
- 已自动同步到国际站。
- 未经客户确认的成交数据可以对外公开。

可以输出：

- 内容资产结构。
- 应用路由表。
- 资料缺口。
- 讲课口径。
- 下一轮访谈问题清单。

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "00_Lead知识资产总控"
  skill: "content-asset-application-router"
  score_before_upgrade: 76
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "知识库 / 脱敏 / 分发:企业知识资产中心Team,内容表达 / 视觉 Brief:内容表达部,询盘 / 报价 / 成交:业务成交部"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "00_Lead知识资产总控"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
