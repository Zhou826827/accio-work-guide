---
name: deal-knowledge-feedback-loop
description: "把业务成交部回流的询盘、报价、异议、成交、丢单和履约反馈沉淀为知识条目、问答、案例和规则缺口；只做知识回流，不处理新询盘推进。"
---

# Deal Knowledge Feedback Loop

## 结论

本 Skill 只负责成交知识回流，不负责处理新询盘、生成首响、报价或跟进节奏。新询盘推进的 primary owner 是业务成交部。

## 输入

```yaml
deal_feedback_pack:
  source_team: "业务成交部"
  inquiry_priority_table:
  reply_objection_trace:
  quotation_decision_boundary:
  deal_review_report:
  lost_reason_library:
  delivery_feedback:
  repurchase_signal:
  human_confirmation_log:
```

## 工作流

1. 检查来源是否来自业务成交部 Leader 交接包。
2. 检查材料是否已脱敏；未脱敏则 blocked。
3. 把新问题沉淀为 `customer_qa_candidates`。
4. 把可公开案例沉淀为 `customer_case_candidates`。
5. 把报价、交期、付款、异议中的规则缺口写入 `knowledge_rule_gap`。
6. 把履约反馈和复购线索写入 `deal_feedback_and_repurchase_signal`。
7. 输出知识库回流报告，不生成对外回复或报价。

## 输出

```yaml
deal_knowledge_feedback_result:
  status: "pass | revise | blocked"
  approved_qa_candidates: []
  approved_case_candidates: []
  internal_only_items: []
  knowledge_rule_gap: []
  deal_feedback_and_repurchase_signal: []
  blocked_reason:
  return_to_team: "业务成交部"
```

## 红线

- 不处理新询盘。
- 不生成英文首响。
- 不输出报价、折扣、账期、付款、交期或物流承诺。
- 不替业务成交部判断跟进节奏。
- 不把未脱敏聊天、报价单、联系人、订单信息写入公开知识库。

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "00_Lead知识资产总控"
  skill: "deal-knowledge-feedback-loop"
  score_before_upgrade: 72
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "询盘 / 报价 / 成交:业务成交部,知识库 / 脱敏 / 分发:企业知识资产中心Team"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "00_Lead知识资产总控"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
