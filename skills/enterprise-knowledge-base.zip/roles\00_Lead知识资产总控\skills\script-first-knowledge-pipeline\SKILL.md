---
name: script-first-knowledge-pipeline
description: "在知识库抽取、读书知识库、企业资料整理或全量批处理前，先用脚本完成可重复的解析、拆分、校验和微任务编排，再把语义判断交给 AI。"
---

# Script First Knowledge Pipeline

## 使用场景

当任务涉及以下任一情况时使用：

- PDF、PPT、录音转写、聊天记录、书籍、企业资料进入知识库。
- 需要批量拆出原理、框架、案例、术语、问答或反模式。
- Agent 在大任务中出现笼统报错、空目录、漏条目、引用悬挂。
- 用户要求提高速度、标准化或减少 AI 算法式随机执行。

## 第一原则

不要让 AI 做流水线。

AI 负责语义抽象和判断；脚本负责可重复、可验证、可复现的工程动作。

## 必读知识

先读取：

- `knowledge/roles/00_Lead知识资产总控/07_脚本优先执行层.md`
- `knowledge/roles/00_Lead知识资产总控/03_角色交接门与返工规则.md`
- `knowledge/roles/03_知识质量与分发官/03_四库条目验收与AI-Slop扫描.md`

## 脚本路径

```bash
agent-ready/Teams/企业知识资产中心Team/scripts/knowledge_pipeline_tools.py
```

## 标准执行顺序

1. 先跑 inventory，确认 raw/schema/sample/full 的真实状态。
2. 再跑 check，确认 ID、引用、source、quote 和 case v0.2 字段。
3. 如果任务超过微任务粒度门，用 microtasks 生成微任务表。
4. 只把单个微任务派给 AI：`1 个 raw section + 1 个库 + ≤5 条`。
5. 每个微任务写完后立刻跑 check。
6. check 通过后再派下一个微任务。
7. 批次完成后由总控做语义验收。

## 常用命令

```bash
python3 agent-ready/Teams/企业知识资产中心Team/scripts/knowledge_pipeline_tools.py inventory --kb-root output/读书知识库/内容红利
```

```bash
python3 agent-ready/Teams/企业知识资产中心Team/scripts/knowledge_pipeline_tools.py check --kb-root output/读书知识库/内容红利
```

```bash
python3 agent-ready/Teams/企业知识资产中心Team/scripts/knowledge_pipeline_tools.py microtasks \
  --kb-root output/读书知识库/内容红利 \
  --batch batch_1 \
  --sections 00_preface.md,01-01_定位与人设.md \
  --libraries principles,cases,glossary,anti_patterns \
  --max-items 5 \
  --write
```

## AI 任务上限

```yaml
one_ai_task:
  raw_sections: 1
  libraries: 1
  max_new_items: 5
  output_file: "明确到单一 yaml/md 文件"
  required_after_write:
    - "run deterministic check"
    - "report file path + IDs + error_count"
```

## 失败处理

如果 Agent 报笼统错误：

1. 不要重派同样的大任务。
2. 先运行 `inventory` 看是否已有半成品。
3. 再运行 `check` 找具体错误。
4. 若目录为空，拆成更小微任务。
5. 若 `check` 有结构错误，先修结构，不继续抽取。

连续两次笼统错误后，任务必须转为脚本诊断，不允许继续盲试。

## 输出

总控输出必须包含：

```yaml
script_first_pipeline_result:
  inventory_checked: true
  check_error_count:
  check_warning_count:
  microtask_plan:
  ai_tasks_allowed:
  blocked_reason:
  next_action:
```

<!-- ACCIO_85_90_GOVERNANCE_UPGRADE_V1 -->

## 8.5-9 分档治理补强

本段用于把本 Skill 从“能完成任务”提升到“可交接、可质检、可复盘、可回流”。执行时必须结论先行，再给依据和动作；不得用模糊措辞替代判断。

## Required Inputs

```yaml
skill_runtime_contract:
  team: "企业知识资产中心Team"
  role: "00_Lead知识资产总控"
  skill: "script-first-knowledge-pipeline"
  score_before_upgrade: 77.2
  evidence_required:
    - upstream_handoff_or_source_index
    - source_file_or_data_snapshot
    - evidence_level
    - data_permission_status
    - customer_goal_or_task_scope
  governance_required:
    - leader_dispatch_packet
    - role_report_path
    - handoff_router
    - quality_gate_result
    - next_customer_questions
  detected_capability_categories: "知识库 / 脱敏 / 分发:企业知识资产中心Team"
```

## Output Contract

必须输出以下字段，不得只给长段解释：

```yaml
skill_result:
  role: "00_Lead知识资产总控"
  conclusion_first: ""
  evidence_used:
    - source:
      field_or_quote:
      confidence:
  decision_or_artifact:
    source_index_or_asset_manifest: ""
    normalized_knowledge_object: ""
    evidence_level_and_permission_status: ""
    distribution_or_feedback_pack: ""
    blocked_items_and_rework_request: ""
  blocked_or_uncertain_items:
    - reason:
      required_evidence:
      owner:
  handoff_router:
    primary_owner:
    evidence_consumers:
    quality_reviewers:
  next_customer_questions:
    - ""
```

## Failure Branches

| 触发条件 | 必须动作 | 禁止动作 |
|---|---|---|
| 输入资料缺失 | 输出 missing_data_pack，只保留假设边界 | 不得输出确定结论 |
| 证据等级低于业务决策要求 | 降级为 hypothesis_only 或 test_only | 不得包装成最终方案 |
| 数据未脱敏或权限不清 | 输出 human_confirmation_required 并阻断 | 不得进入客户版正文 |
| 上游交接缺 intent_expansion | 退回 Leader 补意图包 | 不得自行补写客户目标 |
| 发现跨 Team 问题 | 写入 handoff_router | 不得替 primary owner 下最终判断 |
| 角色输出之间冲突 | 建立冲突板并交 Leader 仲裁 | 不得隐藏冲突 |
| 客户目标中途变化 | 重跑意图识别和接棒判断 | 不得沿旧路径继续交付 |
| 输出缺行动 owner | 阻断交付并补负责人/复盘点 | 不得只写原则 |

## CHECKPOINT

STOP：命中以下任一情况，必须停止自动执行并交给 Leader 或用户确认：

1. 需要登录后台、CRM、OKKI、邮箱、店铺或第三方系统。
2. 需要发送客户消息、报价、折扣、账期、付款、交期、物流承诺。
3. 需要修改、删除、覆盖客户数据或内部资料。
4. 证据不足但用户要求确定结论。
5. 外部能力、脚本、API 或 GitHub 候选需要启用、安装或连接账号。
6. 本 Skill 的判断会改变其他 Team 的主权决策。

## Owner Boundary

共享知识库只做资料接收、脱敏、标准化、知识构建、分发和回流；不替业务 Team 下最终经营判断。

边界规则：

1. 本 Skill 只能处理本角色字段。
2. 下游需要细案时，输出交接包，不跨级生成终稿。
3. 共享知识库只接收脱敏、有来源、有证据等级的回流。
4. 所有 worker 结果必须回到 Leader 综合后再交给下一棒。

## Test Prompts

1. 客户只给一句模糊目标，没有数据，要求输出本 Skill 能做什么、不能做什么、需要补什么。
2. 客户给一份脱敏表格和一段访谈，要求输出结论、证据、阻断项、交接 owner。
3. 上游报告和客户新目标冲突，要求判断是否继续、退回、改路由或进入质量门。

## Verification Checklist

- conclusion_first 不为空。
- 每个判断都绑定 evidence_used。
- blocked_or_uncertain_items 写明缺口和 owner。
- handoff_router.primary_owner 是五大师之一或共享知识库。
- 客户版不出现内部状态码、未解释字段、隐私字段或黑话。
- 角色报告和交接报告分离。
- 需要人审的动作没有被自动执行。

## Do Not

- 不用“大概、可能、差不多”替代判断。
- 不把缺证据的推断写成事实。
- 不把客户隐私、联系人、账号、聊天原文放进客户版报告。
- 不绕过 Leader 直接交给下游 Team。
- 不替其他 Team 做 primary owner 决策。
- 不把脚本通过写成业务通过。
- 不把外部候选写成已接入能力。
- 不输出公文腔、空洞套话或只有原则没有动作的报告。
<!-- marker=ACCIO-PACKAGE-WATERMARK package_id=CUST-133-windows-20260613_1.23.5-All-39f7e2cf81b8 customer_id=CUST-133 auth_batch=20260613-normal scope=team:EKA -->
